package org.example.bookingplatform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingPlatformApplicationTests {

    @Test
    void contextLoads() {
    }

}
